find_equilibrium
